Limits the bandwidth for the specified process
