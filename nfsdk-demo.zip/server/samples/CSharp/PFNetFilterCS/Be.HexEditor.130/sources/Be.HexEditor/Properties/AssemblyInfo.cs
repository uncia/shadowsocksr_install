using System.Reflection;
using System.Runtime.CompilerServices;

//
// General Information about an assembly is controlled through the following 
// set of attributes. Change these attribute values to modify the information
// associated with an assembly.
//
[assembly: AssemblyTitle("Be.HexEditor")]
[assembly: AssemblyDescription("View and edit files in hex format")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("Be")]
[assembly: AssemblyProduct("Be.HexEditor")]
[assembly: AssemblyCopyright("")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]		

[assembly: AssemblyVersion("1.3.0.*")]